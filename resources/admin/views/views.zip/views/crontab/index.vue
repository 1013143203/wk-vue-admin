<template>
  <div class="app-container" >
    <el-card class="show">
      <wk-search
        :query = "search.query"
        :cols = "search.cols"
        @queryClick="queryClick"
      ></wk-search>
      <wk-table-btn
        :btn = "table.btn"
      >
      </wk-table-btn>
      <wk-table
        v-auth="'crontab:index'"
        :total="table.total"
        :cols="table.cols"
        :data="table.lst"
        :options="table.options"
        ref="table"
      ></wk-table>
    </el-card>
    <detail
      :sTypes="form.cols.sType.options"
      :tTypes="form.cols.tType.options"
      ref="edit" ></detail>
  </div>
</template>

<script>
  import { index, status, edit } from "@/api/crontab";
  import detail from "./components/detail";
  export default {
    name: "crontab",
    components: {
      detail
    },
    data() {
      return {
        table: {
          cols: [
            {label:'任务', prop: "name"},
            {label:'周期', prop: "status"},
            {label:'保存数量', prop: "status"},
            {label:'上次执行时间', prop: "status"},
            {
              label:'状态',
              prop: "status",
              type: "switch" ,
              auth: "crontab:status" ,
              switchData: {
                active:1,
                inactive:2,
              },
              switch:(val,id)=>{
                status(val,id)
                  .then((response) => {
                    console.log(response);
                  })
                  .catch((error) => {
                    console.log(error);
                  });
              }
            },
            {
              label:'操作',
              type: "btn",
              btn:[
                {
                  label:'编辑',
                  auth:'crontab:edit',
                  click:(index , item)=>{
                    edit(item.id).then((response) => {
                      const { data } = response;
                      this.$refs.edit.add(data)
                    })
                      .catch((error) => {
                        console.log(error);
                      });
                  }
                },
                {label: "删除" ,type: "danger" , auth:'menu:delete'},
                {
                  label: "添加" ,
                  type: "primary" ,
                  auth:'menu:create',
                  click:(index , item)=>{
                    if(item.type==3){
                      this.$message({
                        type: 'error',
                        message: '不可添加节点'
                      });
                      return
                    }
                    this.add(item)
                  }
                }
              ], width:250,
            },
          ],
          lst: [],
          total: 0,
        },
        search:{

        },
        form: {
          cols: {
            sType:{
              label: "任务类型",
              prop: "sType",
              type: "select",
              options: [
                {
                  id:1,
                  name:'Shell脚本'
                },
                {
                  id:2,
                  name:'访问URL'
                }
              ],
            },
            name:{
              type: "input",
              disabled:false,
              label: "任务名称", //字段
              prop: "name", //字段名
              placeholder: "请填写任务名称", //提示内容
              rules: [
                { required: true, message: "请输入任务名称", trigger: "blur" },
              ],
            },
            tType:{
              prop: "tType",
              type: "select",
              options: [
                {
                  id:1,
                  name:'N天'
                },
                {
                  id:2,
                  name:'N小时'
                },
                {
                  id:3,
                  name:'N分钟'
                },
                {
                  id:4,
                  name:'每周'
                },
                {
                  id:5,
                  name:'每月'
                },
              ],
            },
            week:{
              prop: "week",
              type: "select",
            },
            tt:{
              prop: "tType",
              type: "select",
              options: [],
            },
            ss:{
              prop: "tType",
              type: "select",
              options: [],
            },
          }
        }
      }
    },
    created() {
      this.index();
    },
    methods: {
      index() {
        index(this.search.query)
          .then((response) => {
            const { data } = response;
            const { lst, total } = data;
            this.table.lst = lst;
            this.table.total = total;
          })
          .catch((error) => {
            console.log(error);
          });
      },
      queryClick(query){
        this.search.query=query
        this.index()
      },
    }
  }
</script>

<style scoped>

</style>
